I'm happy you had enough trust to open a zip. 
It reduced the total file size from 190MB to 39MB so I'd say it was worth it. 